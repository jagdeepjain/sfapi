
For instructions on getting the API setup see the project wiki: http://code.google.com/p/sfapi/w/list

Also a sample project and sample JUnit frame work is available for download from the project Google Code site: http://code.google.com/p/sfapi/downloads/list
